/* eslint-disable no-underscore-dangle */
global.___loader = {
  enqueue: jest.fn(),
}
/* eslint-enable no-underscore-dangle */
