import React from "react"

import AppBar from '@material-ui/core/AppBar'

const SearchBar = ({searchChange}) => {
	return (
		<AppBar position="static">
			<input
				type="search" 
				placeholder="Search by Customer Name" 
				onChange = {searchChange}
			/>
		</AppBar>
	)
}

export default SearchBar