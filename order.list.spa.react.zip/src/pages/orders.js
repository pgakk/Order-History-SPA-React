import React, {useState, useEffect} from "react"
import { Link } from "gatsby"

import Layout from "../components/layout"
import SEO from "../components/seo"
import OrderTable from "../components/ordertable"
import SearchBar from "../components/searchbar"

const OrdersPage = () => {
	const [orderData, setOrderData] = React.useState([]);
	const [searchField, setSearchField] = React.useState('');

	React.useEffect(()=> {
		fetch('https://jsonplaceholder.typicode.com/users')
			.then(response => response.json())
			.then(users => setOrderData(users));
	}, []);

	const onSearchChange = (event) => {
		setSearchField(event.target.value);
	}

	const filteredOrders = orderData.filter(order => {
			return order.name.toLowerCase().includes(searchField.toLowerCase());
		})

  return (
  	<Layout>
    	<h1>Orders</h1>
    	<SearchBar searchChange={onSearchChange}/>
    	<OrderTable orders={filteredOrders}></OrderTable><br/>
    	<Link to="/">Go back to the homepage</Link>
  	</Layout>
  )
}

export default OrdersPage
