import React from 'react';
import { Link } from "gatsby"

import Layout from "../components/layout"
import {Grid} from '@material-ui/core';

const OrderDetail = ({location})  => {
  const order  = location.state.order;

  return (
    <Layout>
      <h1>Order Detail</h1>
      <div>Order ID: {order.id}</div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <div>Name: {order.name}</div>
        </Grid>
        <Grid item xs={6}>
          <div>Email: {order.email}</div>
        </Grid>
        <Grid item xs={6}>
          <div> Address: {`${order.address.suite} ${order.address.street}, ${order.address.city}, ${order.address.zipcode}`} </div>
        </Grid>
      </Grid>
      <br/>
      <Link to="/orders/">Go back to orders</Link>
    </Layout>
  )
}

export default OrderDetail
